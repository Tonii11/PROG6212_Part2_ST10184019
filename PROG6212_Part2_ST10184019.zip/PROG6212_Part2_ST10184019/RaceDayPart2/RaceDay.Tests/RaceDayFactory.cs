namespace RaceDay.Tests;

/// <summary>
/// Boots the real API in memory and swaps SQL Server for an isolated EF Core in-memory database,
/// so tests exercise the real controllers, session handling and role filters without needing SQL Server.
/// </summary>
public class RaceDayFactory : WebApplicationFactory<Program>
{
    private readonly string _databaseName = "RaceDayTests-" + Guid.NewGuid();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureServices(services =>
        {
            var existing = services
                .Where(d => d.ServiceType == typeof(DbContextOptions<RaceDayDbContext>))
                .ToList();
            foreach (var descriptor in existing) services.Remove(descriptor);

            services.AddDbContext<RaceDayDbContext>(options => options.UseInMemoryDatabase(_databaseName));
        });
    }

    /// <summary>Run code directly against the test database (used to inspect or arrange data).</summary>
    public async Task WithDbAsync(Func<RaceDayDbContext, Task> action)
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
        await action(db);
    }
}

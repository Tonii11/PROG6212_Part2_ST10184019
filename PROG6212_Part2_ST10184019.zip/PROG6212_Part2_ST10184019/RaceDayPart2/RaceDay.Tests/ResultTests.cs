namespace RaceDay.Tests;

public class ResultTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public ResultTests(RaceDayFactory factory) => _factory = factory;

    /// <summary>Organiser + enrolled participant for an event that has now taken place.</summary>
    private async Task<(HttpClient Organiser, HttpClient Participant, int EventId, int EnrolmentId)> CompletedEventAsync()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");

        var enrolResponse = await EnrolAsync(participant, ev.EventId, category.CategoryId);
        enrolResponse.EnsureSuccessStatusCode();
        var enrolment = (await enrolResponse.Content.ReadFromJsonAsync<EnrolmentDto>())!;

        // Enrolment is only possible before the event, so move the event into the past afterwards.
        await _factory.WithDbAsync(async db =>
        {
            var row = await db.Events.SingleAsync(e => e.EventID == ev.EventId);
            row.EventDate = DateTime.Now.AddDays(-1);
            await db.SaveChangesAsync();
        });

        return (organiser, participant, ev.EventId, enrolment.EnrolmentId);
    }

    [Fact]
    public async Task Organiser_CanCaptureResult_Returns201()
    {
        var (organiser, _, _, enrolmentId) = await CompletedEventAsync();

        var response = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var result = await response.Content.ReadFromJsonAsync<ResultDto>();
        Assert.Equal(2415, result!.FinishTimeSeconds);
        Assert.Equal("00:40:15", result.FinishTime);
        Assert.Equal(47, result.FinishPosition);
        Assert.Equal(312, result.TotalFinishers);
    }

    [Fact]
    public async Task Participant_SeesOwnResult_WithEventDetails()
    {
        var (organiser, participant, eventId, enrolmentId) = await CompletedEventAsync();
        (await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest()))
            .EnsureSuccessStatusCode();

        var results = await participant.GetFromJsonAsync<List<ResultDto>>("/api/users/me/results");

        var mine = Assert.Single(results!);
        Assert.Equal(eventId, mine.EventId);
        Assert.Equal("Test Event", mine.EventName);
        Assert.Equal("Open", mine.CategoryName);
        Assert.Equal(47, mine.FinishPosition);
    }

    [Fact]
    public async Task Participant_DoesNotSeeSomeoneElsesResults()
    {
        var (organiser, _, _, enrolmentId) = await CompletedEventAsync();
        (await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest()))
            .EnsureSuccessStatusCode();
        var stranger = await LoggedInClientAsync(_factory, "Participant");

        var results = await stranger.GetFromJsonAsync<List<ResultDto>>("/api/users/me/results");

        Assert.Empty(results!);
    }

    [Fact]
    public async Task Participant_CannotCaptureResult_Returns403()
    {
        var (_, participant, _, enrolmentId) = await CompletedEventAsync();

        var response = await participant.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotCaptureResult_Returns401()
    {
        var (_, _, _, enrolmentId) = await CompletedEventAsync();
        var anonymous = _factory.CreateClient();

        var response = await anonymous.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotCaptureResultForAnotherOrganisersEvent_Returns403()
    {
        var (_, _, _, enrolmentId) = await CompletedEventAsync();
        var otherOrganiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await otherOrganiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_Twice_Returns409()
    {
        var (organiser, _, _, enrolmentId) = await CompletedEventAsync();
        (await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest()))
            .EnsureSuccessStatusCode();

        var second = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_PositionGreaterThanFinishers_Returns400()
    {
        var (organiser, _, _, enrolmentId) = await CompletedEventAsync();
        var request = new ResultRequest { FinishTimeSeconds = 2000, FinishPosition = 10, TotalFinishers = 5 };

        var response = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_ZeroFinishTime_Returns400()
    {
        var (organiser, _, _, enrolmentId) = await CompletedEventAsync();
        var request = new ResultRequest { FinishTimeSeconds = 0, FinishPosition = 1, TotalFinishers = 5 };

        var response = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_BeforeEventHasHappened_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser); // 30 days in the future
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var enrolment = (await (await EnrolAsync(participant, ev.EventId, category.CategoryId))
            .Content.ReadFromJsonAsync<EnrolmentDto>())!;

        var response = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentId}/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_UnknownEnrolment_Returns404()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/enrolments/999999/results", NewResultRequest());

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanViewResultsForOwnEvent()
    {
        var (organiser, _, eventId, enrolmentId) = await CompletedEventAsync();
        (await organiser.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/results", NewResultRequest()))
            .EnsureSuccessStatusCode();

        var results = await organiser.GetFromJsonAsync<List<ResultDto>>($"/api/events/{eventId}/results");

        Assert.Single(results!);
    }

    [Fact]
    public async Task Participant_CannotViewEventResultsEndpoint_Returns403()
    {
        var (_, participant, eventId, _) = await CompletedEventAsync();

        var response = await participant.GetAsync($"/api/events/{eventId}/results");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotViewParticipantOnlyResultsList_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.GetAsync("/api/users/me/results");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}

namespace RaceDay.Tests;

public class EnrolmentTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public EnrolmentTests(RaceDayFactory factory) => _factory = factory;

    [Fact]
    public async Task Participant_CanEnrol_AndEnrolmentIsRecorded()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var me = await participant.GetFromJsonAsync<UserProfileDto>("/api/users/me");

        var response = await EnrolAsync(participant, ev.EventId, category.CategoryId);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var created = await response.Content.ReadFromJsonAsync<EnrolmentDto>();
        Assert.Equal(ev.EventId, created!.EventId);
        Assert.Equal(category.CategoryId, created.CategoryId);
        Assert.Equal("Confirmed", created.EnrolmentStatus);

        // The participant, event and category link is really stored in the database.
        await _factory.WithDbAsync(async db =>
        {
            var row = await db.Enrolments.SingleAsync(e => e.EnrolmentID == created.EnrolmentId);
            Assert.Equal(me!.UserId, row.ParticipantID);
            Assert.Equal(ev.EventId, row.EventID);
            Assert.Equal(category.CategoryId, row.CategoryID);
        });
    }

    [Fact]
    public async Task Participant_SeesOwnEnrolments()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var other = await LoggedInClientAsync(_factory, "Participant");
        (await EnrolAsync(participant, ev.EventId, category.CategoryId)).EnsureSuccessStatusCode();

        var mine = await participant.GetFromJsonAsync<List<EnrolmentDto>>("/api/users/me/enrolments");
        var theirs = await other.GetFromJsonAsync<List<EnrolmentDto>>("/api/users/me/enrolments");

        Assert.Contains(mine!, e => e.EventId == ev.EventId && e.CategoryId == category.CategoryId);
        Assert.Empty(theirs!);
    }

    [Fact]
    public async Task Enrol_TwiceForSameEvent_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");
        (await EnrolAsync(participant, ev.EventId, category.CategoryId)).EnsureSuccessStatusCode();

        var second = await EnrolAsync(participant, ev.EventId, category.CategoryId);

        Assert.Equal(HttpStatusCode.BadRequest, second.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotEnrol_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var response = await EnrolAsync(organiser, ev.EventId, category.CategoryId);

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotEnrol_Returns401()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var anonymous = _factory.CreateClient();

        var response = await EnrolAsync(anonymous, ev.EventId, category.CategoryId);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_UnknownEvent_Returns404()
    {
        var participant = await LoggedInClientAsync(_factory, "Participant");

        var response = await EnrolAsync(participant, 999999, 1);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_UnknownCategory_Returns404()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var participant = await LoggedInClientAsync(_factory, "Participant");

        var response = await EnrolAsync(participant, ev.EventId, 999999);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_WithCategoryFromAnotherEvent_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var eventA = await CreateEventAsync(organiser);
        var eventB = await CreateEventAsync(organiser);
        var categoryOfB = await CreateCategoryAsync(organiser, eventB.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");

        var response = await EnrolAsync(participant, eventA.EventId, categoryOfB.CategoryId);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_ForEventThatAlreadyHappened_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var pastEvent = await CreateEventAsync(organiser, NewEventRequest(DateTime.Now.AddDays(-5)));
        var category = await CreateCategoryAsync(organiser, pastEvent.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");

        var response = await EnrolAsync(participant, pastEvent.EventId, category.CategoryId);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanViewEnrolmentsForOwnEvent()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var participant = await LoggedInClientAsync(_factory, "Participant");
        (await EnrolAsync(participant, ev.EventId, category.CategoryId)).EnsureSuccessStatusCode();

        var response = await organiser.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var list = await response.Content.ReadFromJsonAsync<List<EnrolmentDto>>();
        Assert.Single(list!);
        Assert.Equal(category.CategoryId, list![0].CategoryId);
    }

    [Fact]
    public async Task Organiser_CannotViewEnrolmentsForAnotherOrganisersEvent_Returns403()
    {
        var owner = await LoggedInClientAsync(_factory, "Organiser");
        var other = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(owner);

        var response = await other.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewEventEnrolments_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);

        var response = await participant.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotViewParticipantOnlyEnrolmentList_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.GetAsync("/api/users/me/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}

namespace RaceDay.Tests;

public class CategoryTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public CategoryTests(RaceDayFactory factory) => _factory = factory;

    [Fact]
    public async Task Organiser_CanAddCategory_AndAnyoneCanListIt()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);

        var created = await CreateCategoryAsync(organiser, ev.EventId);
        var anonymous = _factory.CreateClient();
        var list = await anonymous.GetFromJsonAsync<List<CategoryDto>>($"/api/events/{ev.EventId}/categories");

        Assert.Equal(ev.EventId, created.EventId);
        Assert.Contains(list!, c => c.CategoryId == created.CategoryId);
    }

    [Fact]
    public async Task Participant_CannotAddCategory_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);

        var response = await participant.PostAsJsonAsync($"/api/events/{ev.EventId}/categories",
            new CategoryRequest { CategoryName = "Sneaky" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotAddCategoryToAnotherOrganisersEvent_Returns403()
    {
        var owner = await LoggedInClientAsync(_factory, "Organiser");
        var other = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(owner);

        var response = await other.PostAsJsonAsync($"/api/events/{ev.EventId}/categories",
            new CategoryRequest { CategoryName = "Not mine" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task AddCategory_MinAgeGreaterThanMaxAge_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);

        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/categories",
            new CategoryRequest { CategoryName = "Broken", MinAge = 50, MaxAge = 20 });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task AddCategory_ToUnknownEvent_Returns404()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events/999999/categories",
            new CategoryRequest { CategoryName = "Ghost" });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task ListCategories_ForUnknownEvent_Returns404()
    {
        var anonymous = _factory.CreateClient();

        var response = await anonymous.GetAsync("/api/events/999999/categories");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnCategory_Returns204()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var response = await organiser.DeleteAsync($"/api/categories/{category.CategoryId}");

        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotDeleteCategory_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);

        var response = await participant.DeleteAsync($"/api/categories/{category.CategoryId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task DeleteCategory_WithEnrolments_Returns409()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        (await EnrolAsync(participant, ev.EventId, category.CategoryId)).EnsureSuccessStatusCode();

        var response = await organiser.DeleteAsync($"/api/categories/{category.CategoryId}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task DeleteCategory_Unknown_Returns404()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.DeleteAsync("/api/categories/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}

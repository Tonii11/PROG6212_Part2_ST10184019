namespace RaceDay.Tests;

public static class TestHelpers
{
    public const string Password = "Passw0rd!";

    public static string UniqueEmail(string prefix = "user") =>
        $"{prefix}.{Guid.NewGuid():N}@test.raceday.co.za";

    public static Task<HttpResponseMessage> RegisterAsync(
        HttpClient client, string role, string? email = null, string password = Password)
    {
        var body = new RegisterRequest
        {
            FirstName = "Test",
            LastName = role,
            Email = email ?? UniqueEmail(),
            Password = password,
            Role = role,
            PhoneNumber = "0820000000"
        };
        return client.PostAsJsonAsync("/api/auth/register", body);
    }

    public static Task<HttpResponseMessage> LoginAsync(HttpClient client, string email, string password = Password) =>
        client.PostAsJsonAsync("/api/auth/login", new LoginRequest { Email = email, Password = password });

    /// <summary>Creates a fresh client that has registered and logged in as the given role.</summary>
    public static async Task<HttpClient> LoggedInClientAsync(RaceDayFactory factory, string role)
    {
        var client = factory.CreateClient();
        var email = UniqueEmail(role.ToLowerInvariant());
        (await RegisterAsync(client, role, email)).EnsureSuccessStatusCode();
        (await LoginAsync(client, email)).EnsureSuccessStatusCode();
        return client;
    }

    public static EventRequest NewEventRequest(DateTime? date = null, string type = "Run") => new()
    {
        EventName = "Test Event",
        Description = "A test event.",
        EventDate = date ?? DateTime.Now.AddDays(30),
        Location = "Sandton, Johannesburg",
        DistanceKm = 10m,
        EventType = type
    };

    public static async Task<EventDto> CreateEventAsync(HttpClient organiser, EventRequest? request = null)
    {
        var response = await organiser.PostAsJsonAsync("/api/events", request ?? NewEventRequest());
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EventDto>())!;
    }

    public static async Task<CategoryDto> CreateCategoryAsync(HttpClient organiser, int eventId)
    {
        var response = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories",
            new CategoryRequest { CategoryName = "Open", MinAge = 16, MaxAge = 99, CategoryDistanceKm = 10m });
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<CategoryDto>())!;
    }

    public static Task<HttpResponseMessage> EnrolAsync(HttpClient participant, int eventId, int categoryId) =>
        participant.PostAsJsonAsync($"/api/events/{eventId}/enrolments", new EnrolRequest { CategoryId = categoryId });

    public static ResultRequest NewResultRequest() => new()
    {
        FinishTimeSeconds = 2415,
        FinishPosition = 47,
        TotalFinishers = 312
    };
}

namespace RaceDay.Tests;

public class EventTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public EventTests(RaceDayFactory factory) => _factory = factory;

    [Fact]
    public async Task Organiser_CanCreateEvent_Returns201()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", NewEventRequest());

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var ev = await response.Content.ReadFromJsonAsync<EventDto>();
        Assert.Equal("Test Event", ev!.EventName);
        Assert.Equal("Run", ev.EventType);
        Assert.True(ev.EventId > 0);
    }

    [Fact]
    public async Task Participant_CannotCreateEvent_Returns403()
    {
        var participant = await LoggedInClientAsync(_factory, "Participant");

        var response = await participant.PostAsJsonAsync("/api/events", NewEventRequest());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotCreateEvent_Returns401()
    {
        var anonymous = _factory.CreateClient();

        var response = await anonymous.PostAsJsonAsync("/api/events", NewEventRequest());

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_InvalidEventType_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", NewEventRequest(type: "Swim"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_MissingName_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var request = NewEventRequest();
        request.EventName = "";

        var response = await organiser.PostAsJsonAsync("/api/events", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_ZeroDistance_Returns400()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var request = NewEventRequest();
        request.DistanceKm = 0;

        var response = await organiser.PostAsJsonAsync("/api/events", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task EventList_IsPublic_AndContainsCreatedEvent()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var created = await CreateEventAsync(organiser);
        var anonymous = _factory.CreateClient();

        var response = await anonymous.GetAsync("/api/events");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var events = await response.Content.ReadFromJsonAsync<List<EventDto>>();
        Assert.Contains(events!, e => e.EventId == created.EventId);
    }

    [Fact]
    public async Task EventList_CanFilterByType()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var cycle = await CreateEventAsync(organiser, NewEventRequest(type: "Cycle"));
        var walk = await CreateEventAsync(organiser, NewEventRequest(type: "Walk"));
        var anonymous = _factory.CreateClient();

        var events = await anonymous.GetFromJsonAsync<List<EventDto>>("/api/events?type=Cycle");

        Assert.Contains(events!, e => e.EventId == cycle.EventId);
        Assert.DoesNotContain(events!, e => e.EventId == walk.EventId);
    }

    [Fact]
    public async Task EventList_UnknownType_Returns400()
    {
        var anonymous = _factory.CreateClient();

        var response = await anonymous.GetAsync("/api/events?type=Swim");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetEvent_IncludesItsCategories()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        var anonymous = _factory.CreateClient();

        var detail = await anonymous.GetFromJsonAsync<EventDto>($"/api/events/{ev.EventId}");

        Assert.NotNull(detail!.Categories);
        Assert.Contains(detail.Categories!, c => c.CategoryId == category.CategoryId);
    }

    [Fact]
    public async Task GetEvent_Unknown_Returns404()
    {
        var anonymous = _factory.CreateClient();

        var response = await anonymous.GetAsync("/api/events/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdateOwnEvent_Returns200()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var update = NewEventRequest(type: "Walk");
        update.EventName = "Renamed Event";

        var response = await organiser.PutAsJsonAsync($"/api/events/{ev.EventId}", update);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.Content.ReadFromJsonAsync<EventDto>();
        Assert.Equal("Renamed Event", updated!.EventName);
        Assert.Equal("Walk", updated.EventType);
    }

    [Fact]
    public async Task Organiser_CannotUpdateAnotherOrganisersEvent_Returns403()
    {
        var owner = await LoggedInClientAsync(_factory, "Organiser");
        var other = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(owner);

        var response = await other.PutAsJsonAsync($"/api/events/{ev.EventId}", NewEventRequest());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotUpdateEvent_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);

        var response = await participant.PutAsJsonAsync($"/api/events/{ev.EventId}", NewEventRequest());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task UpdateEvent_Unknown_Returns404()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");

        var response = await organiser.PutAsJsonAsync("/api/events/999999", NewEventRequest());

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnEvent_Returns204ThenEventIsGone()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        await CreateCategoryAsync(organiser, ev.EventId);

        var delete = await organiser.DeleteAsync($"/api/events/{ev.EventId}");
        var afterwards = await organiser.GetAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, afterwards.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotDeleteEvent_Returns403()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);

        var response = await participant.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteAnotherOrganisersEvent_Returns403()
    {
        var owner = await LoggedInClientAsync(_factory, "Organiser");
        var other = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(owner);

        var response = await other.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task DeleteEvent_WithEnrolments_Returns409()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var participant = await LoggedInClientAsync(_factory, "Participant");
        var ev = await CreateEventAsync(organiser);
        var category = await CreateCategoryAsync(organiser, ev.EventId);
        (await EnrolAsync(participant, ev.EventId, category.CategoryId)).EnsureSuccessStatusCode();

        var response = await organiser.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotDeleteEvent_Returns401()
    {
        var organiser = await LoggedInClientAsync(_factory, "Organiser");
        var ev = await CreateEventAsync(organiser);
        var anonymous = _factory.CreateClient();

        var response = await anonymous.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}

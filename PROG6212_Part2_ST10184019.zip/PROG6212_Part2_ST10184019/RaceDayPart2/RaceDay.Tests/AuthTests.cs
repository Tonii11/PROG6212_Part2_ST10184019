namespace RaceDay.Tests;

public class AuthTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public AuthTests(RaceDayFactory factory) => _factory = factory;

    // ------------------------------------------------------------ Registration

    [Theory]
    [InlineData("Participant")]
    [InlineData("Organiser")]
    public async Task Register_WithValidDetails_Returns201AndProfile(string role)
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();

        var response = await RegisterAsync(client, role, email);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var profile = await response.Content.ReadFromJsonAsync<UserProfileDto>();
        Assert.Equal(email, profile!.Email);
        Assert.Equal(role, profile.Role);
    }

    [Fact]
    public async Task Register_RoleIsCaseInsensitive()
    {
        var client = _factory.CreateClient();

        var response = await RegisterAsync(client, "organiser");

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var profile = await response.Content.ReadFromJsonAsync<UserProfileDto>();
        Assert.Equal("Organiser", profile!.Role);
    }

    [Fact]
    public async Task Register_DuplicateEmail_Returns409()
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();
        (await RegisterAsync(client, "Participant", email)).EnsureSuccessStatusCode();

        var second = await RegisterAsync(client, "Organiser", email);

        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Register_UnknownRole_Returns400()
    {
        var client = _factory.CreateClient();

        var response = await RegisterAsync(client, "Admin");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_PasswordTooShort_Returns400()
    {
        var client = _factory.CreateClient();

        var response = await RegisterAsync(client, "Participant", password: "abc");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_InvalidEmail_Returns400()
    {
        var client = _factory.CreateClient();

        var response = await RegisterAsync(client, "Participant", email: "not-an-email");

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_MissingFields_Returns400()
    {
        var client = _factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/auth/register", new { });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_PasswordIsHashedInTheDatabase()
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();
        (await RegisterAsync(client, "Participant", email)).EnsureSuccessStatusCode();

        await _factory.WithDbAsync(async db =>
        {
            var user = await db.Users.SingleAsync(u => u.Email == email);
            Assert.NotEqual(Password, user.PasswordHash);
            Assert.DoesNotContain(Password, user.PasswordHash);
            Assert.False(string.IsNullOrWhiteSpace(user.PasswordHash));
        });
    }

    // ------------------------------------------------------------ Login

    [Theory]
    [InlineData("Participant")]
    [InlineData("Organiser")]
    public async Task Login_WithValidCredentials_Returns200AndRole(string role)
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();
        (await RegisterAsync(client, role, email)).EnsureSuccessStatusCode();

        var response = await LoginAsync(client, email);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<LoginResponse>();
        Assert.Equal(role, body!.Role);
        Assert.Equal(email, body.User.Email);
    }

    [Fact]
    public async Task Login_WrongPassword_Returns401()
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();
        (await RegisterAsync(client, "Participant", email)).EnsureSuccessStatusCode();

        var response = await LoginAsync(client, email, "WrongPassword1!");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_UnknownEmail_Returns401()
    {
        var client = _factory.CreateClient();

        var response = await LoginAsync(client, UniqueEmail("nobody"));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_EmailIsCaseInsensitive()
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();
        (await RegisterAsync(client, "Participant", email)).EnsureSuccessStatusCode();

        var response = await LoginAsync(client, email.ToUpperInvariant());

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    // ------------------------------------------------------------ Session

    [Fact]
    public async Task Profile_WithoutLogin_Returns401()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/api/users/me");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Profile_AfterLogin_ReturnsOwnProfile()
    {
        var client = _factory.CreateClient();
        var email = UniqueEmail();
        (await RegisterAsync(client, "Participant", email)).EnsureSuccessStatusCode();
        (await LoginAsync(client, email)).EnsureSuccessStatusCode();

        var profile = await client.GetFromJsonAsync<UserProfileDto>("/api/users/me");

        Assert.Equal(email, profile!.Email);
        Assert.Equal("Participant", profile.Role);
    }

    [Fact]
    public async Task Logout_ClearsTheSession()
    {
        var client = await LoggedInClientAsync(_factory, "Participant");
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync("/api/users/me")).StatusCode);

        var logout = await client.PostAsync("/api/auth/logout", null);
        var afterLogout = await client.GetAsync("/api/users/me");

        Assert.Equal(HttpStatusCode.OK, logout.StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, afterLogout.StatusCode);
    }

    [Fact]
    public async Task Logout_WithoutLogin_Returns401()
    {
        var client = _factory.CreateClient();

        var response = await client.PostAsync("/api/auth/logout", null);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    // ------------------------------------------------------------ Profile update

    [Fact]
    public async Task UpdateProfile_ChangesNamesAndPhone()
    {
        var client = await LoggedInClientAsync(_factory, "Participant");

        var response = await client.PutAsJsonAsync("/api/users/me",
            new UpdateProfileRequest { FirstName = "Thandeka", LastName = "Mokoena", PhoneNumber = "0712223333" });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var profile = await client.GetFromJsonAsync<UserProfileDto>("/api/users/me");
        Assert.Equal("Thandeka", profile!.FirstName);
        Assert.Equal("0712223333", profile.PhoneNumber);
    }

    [Fact]
    public async Task UpdateProfile_WithoutLogin_Returns401()
    {
        var client = _factory.CreateClient();

        var response = await client.PutAsJsonAsync("/api/users/me",
            new UpdateProfileRequest { FirstName = "A", LastName = "B" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task UpdateProfile_MissingFirstName_Returns400()
    {
        var client = await LoggedInClientAsync(_factory, "Organiser");

        var response = await client.PutAsJsonAsync("/api/users/me",
            new UpdateProfileRequest { FirstName = "", LastName = "Khumalo" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }
}

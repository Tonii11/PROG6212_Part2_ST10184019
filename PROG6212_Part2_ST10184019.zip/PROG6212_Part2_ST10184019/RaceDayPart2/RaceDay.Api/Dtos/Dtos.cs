using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using RaceDay.Api.Models;

namespace RaceDay.Api.Dtos;

/// <summary>Simple message body used for errors and confirmations.</summary>
public class MessageResponse
{
    public string Message { get; set; } = string.Empty;
    public MessageResponse() { }
    public MessageResponse(string message) => Message = message;
}

// ---------------------------------------------------------------- Auth / users
public class RegisterRequest
{
    [Required, StringLength(50)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(50)] public string LastName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(100)] public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = string.Empty;
    /// <summary>Either "Organiser" or "Participant".</summary>
    [Required] public string Role { get; set; } = string.Empty;
    [StringLength(20)] public string? PhoneNumber { get; set; }
}

public class LoginRequest
{
    [Required] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
}

public class UpdateProfileRequest
{
    [Required, StringLength(50)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(50)] public string LastName { get; set; } = string.Empty;
    [StringLength(20)] public string? PhoneNumber { get; set; }
}

public class UserProfileDto
{
    public int UserId { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string? ProfileImageUrl { get; set; }
    public string Role { get; set; } = string.Empty;
    public DateTime DateRegistered { get; set; }

    public static UserProfileDto From(User u) => new()
    {
        UserId = u.UserID,
        FirstName = u.FirstName,
        LastName = u.LastName,
        Email = u.Email,
        PhoneNumber = u.PhoneNumber,
        ProfileImageUrl = u.ProfileImageUrl,
        Role = u.Role?.RoleName ?? string.Empty,
        DateRegistered = u.DateRegistered
    };
}

public class LoginResponse
{
    public string Role { get; set; } = string.Empty;
    public UserProfileDto User { get; set; } = new();
}

// ---------------------------------------------------------------- Events
public class EventRequest
{
    [Required, StringLength(100)] public string EventName { get; set; } = string.Empty;
    [StringLength(1000)] public string? Description { get; set; }
    [Required] public DateTime? EventDate { get; set; }
    [Required, StringLength(150)] public string Location { get; set; } = string.Empty;
    [Range(0.01, 99999)] public decimal DistanceKm { get; set; }
    /// <summary>Run, Walk or Cycle.</summary>
    [Required] public string EventType { get; set; } = string.Empty;
}

public class EventDto
{
    public int EventId { get; set; }
    public int OrganiserId { get; set; }
    public string OrganiserName { get; set; } = string.Empty;
    public string EventName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string? BannerImageUrl { get; set; }
    public DateTime CreatedAt { get; set; }

    /// <summary>Only populated by GET /api/events/{id}.</summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public List<CategoryDto>? Categories { get; set; }

    public static EventDto From(RaceEvent e, bool includeCategories = false) => new()
    {
        EventId = e.EventID,
        OrganiserId = e.OrganiserID,
        OrganiserName = e.Organiser is null ? string.Empty : $"{e.Organiser.FirstName} {e.Organiser.LastName}",
        EventName = e.EventName,
        Description = e.Description,
        EventDate = e.EventDate,
        Location = e.Location,
        DistanceKm = e.DistanceKM,
        EventType = e.EventType,
        BannerImageUrl = e.BannerImageUrl,
        CreatedAt = e.CreatedAt,
        Categories = includeCategories
            ? e.Categories.OrderBy(c => c.CategoryID).Select(CategoryDto.From).ToList()
            : null
    };
}

// ---------------------------------------------------------------- Categories
public class CategoryRequest
{
    [Required, StringLength(50)] public string CategoryName { get; set; } = string.Empty;
    [Range(0, 120)] public int? MinAge { get; set; }
    [Range(0, 120)] public int? MaxAge { get; set; }
    [Range(0.01, 99999)] public decimal? CategoryDistanceKm { get; set; }
}

public class CategoryDto
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int? MinAge { get; set; }
    public int? MaxAge { get; set; }
    public decimal? CategoryDistanceKm { get; set; }

    public static CategoryDto From(Category c) => new()
    {
        CategoryId = c.CategoryID,
        EventId = c.EventID,
        CategoryName = c.CategoryName,
        MinAge = c.MinAge,
        MaxAge = c.MaxAge,
        CategoryDistanceKm = c.CategoryDistanceKM
    };
}

// ---------------------------------------------------------------- Enrolments
public class EnrolRequest
{
    [Range(1, int.MaxValue)] public int CategoryId { get; set; }
}

public class EnrolmentDto
{
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public string ParticipantEmail { get; set; } = string.Empty;
    public DateTime EnrolmentDate { get; set; }
    public string EnrolmentStatus { get; set; } = string.Empty;

    public static EnrolmentDto From(Enrolment e) => new()
    {
        EnrolmentId = e.EnrolmentID,
        EventId = e.EventID,
        EventName = e.Event?.EventName ?? string.Empty,
        EventDate = e.Event?.EventDate ?? default,
        CategoryId = e.CategoryID,
        CategoryName = e.Category?.CategoryName ?? string.Empty,
        ParticipantId = e.ParticipantID,
        ParticipantName = e.Participant is null ? string.Empty : $"{e.Participant.FirstName} {e.Participant.LastName}",
        ParticipantEmail = e.Participant?.Email ?? string.Empty,
        EnrolmentDate = e.EnrolmentDate,
        EnrolmentStatus = e.EnrolmentStatus
    };
}

// ---------------------------------------------------------------- Results
public class ResultRequest
{
    [Range(1, int.MaxValue)] public int FinishTimeSeconds { get; set; }
    [Range(1, int.MaxValue)] public int FinishPosition { get; set; }
    [Range(1, int.MaxValue)] public int TotalFinishers { get; set; }
}

public class ResultDto
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public string ParticipantName { get; set; } = string.Empty;
    public int FinishTimeSeconds { get; set; }
    /// <summary>hh:mm:ss form of FinishTimeSeconds.</summary>
    public string FinishTime { get; set; } = string.Empty;
    public int FinishPosition { get; set; }
    public int TotalFinishers { get; set; }
    public DateTime DateCaptured { get; set; }

    public static ResultDto From(RaceResult r)
    {
        var ts = TimeSpan.FromSeconds(r.FinishTimeSeconds);
        return new ResultDto
        {
            ResultId = r.ResultID,
            EnrolmentId = r.EnrolmentID,
            EventId = r.Enrolment.EventID,
            EventName = r.Enrolment.Event?.EventName ?? string.Empty,
            EventDate = r.Enrolment.Event?.EventDate ?? default,
            CategoryName = r.Enrolment.Category?.CategoryName ?? string.Empty,
            ParticipantName = r.Enrolment.Participant is null
                ? string.Empty
                : $"{r.Enrolment.Participant.FirstName} {r.Enrolment.Participant.LastName}",
            FinishTimeSeconds = r.FinishTimeSeconds,
            FinishTime = $"{(int)ts.TotalHours:00}:{ts.Minutes:00}:{ts.Seconds:00}",
            FinishPosition = r.FinishPosition,
            TotalFinishers = r.TotalFinishers,
            DateCaptured = r.DateCaptured
        };
    }
}

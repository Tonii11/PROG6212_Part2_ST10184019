using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class CategoriesController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public CategoriesController(RaceDayDbContext db) => _db = db;

    /// <summary>List all categories available for an event.</summary>
    /// <remarks>Role required: none (public).</remarks>
    /// <response code="200">Array of categories.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("events/{eventId:int}/categories")]
    [ProducesResponseType(typeof(List<CategoryDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCategories(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.EventID == eventId))
            return Fail(StatusCodes.Status404NotFound, "Event not found.");

        var categories = await _db.Categories.Where(c => c.EventID == eventId)
            .OrderBy(c => c.CategoryID).ToListAsync();
        return Ok(categories.Select(CategoryDto.From).ToList());
    }

    /// <summary>Add an age/distance category to an event owned by the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser (owner of the event).</remarks>
    /// <response code="201">The new category.</response>
    /// <response code="400">Validation failed (e.g. minimum age greater than maximum age).</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpPost("events/{eventId:int}/categories")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(typeof(CategoryDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> CreateCategory(int eventId, [FromBody] CategoryRequest request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");
        if (ev.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only add categories to events that you created.");

        if (request.MinAge.HasValue && request.MaxAge.HasValue && request.MinAge > request.MaxAge)
            return Fail(StatusCodes.Status400BadRequest, "Minimum age cannot be greater than maximum age.");

        var category = new Category
        {
            EventID = eventId,
            CategoryName = request.CategoryName.Trim(),
            MinAge = request.MinAge,
            MaxAge = request.MaxAge,
            CategoryDistanceKM = request.CategoryDistanceKm
        };
        _db.Categories.Add(category);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetCategories), new { eventId }, CategoryDto.From(category));
    }

    /// <summary>Remove a category from an event owned by the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser (owner of the event).</remarks>
    /// <response code="204">Category deleted.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Category does not exist.</response>
    /// <response code="409">Participants are already enrolled under this category.</response>
    [HttpDelete("categories/{id:int}")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var category = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category is null) return Fail(StatusCodes.Status404NotFound, "Category not found.");
        if (category.Event.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only remove categories from events that you created.");

        if (await _db.Enrolments.AnyAsync(e => e.CategoryID == id))
            return Fail(StatusCodes.Status409Conflict,
                "Participants are already enrolled under this category, so it cannot be removed.");

        _db.Categories.Remove(category);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}

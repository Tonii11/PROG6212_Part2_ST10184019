using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/events")]
public class EventsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public EventsController(RaceDayDbContext db) => _db = db;

    /// <summary>List events, with optional filters.</summary>
    /// <remarks>Role required: none (public).</remarks>
    /// <param name="date">Only events taking place on this calendar day.</param>
    /// <param name="type">Run, Walk or Cycle.</param>
    /// <param name="location">Text contained in the event location.</param>
    /// <param name="upcoming">When true, only events that have not happened yet.</param>
    /// <response code="200">Array of events ordered by date.</response>
    /// <response code="400">Unknown event type.</response>
    [HttpGet]
    [ProducesResponseType(typeof(List<EventDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetEvents(
        [FromQuery] DateTime? date, [FromQuery] string? type,
        [FromQuery] string? location, [FromQuery] bool upcoming = false)
    {
        var query = _db.Events.Include(e => e.Organiser).AsQueryable();

        if (date.HasValue)
        {
            var start = date.Value.Date;
            var end = start.AddDays(1);
            query = query.Where(e => e.EventDate >= start && e.EventDate < end);
        }

        if (!string.IsNullOrWhiteSpace(type))
        {
            var normalised = EventTypes.Normalise(type);
            if (normalised is null)
                return Fail(StatusCodes.Status400BadRequest, "Event type must be Run, Walk or Cycle.");
            query = query.Where(e => e.EventType == normalised);
        }

        if (!string.IsNullOrWhiteSpace(location))
        {
            var loc = location.Trim();
            query = query.Where(e => e.Location.Contains(loc));
        }

        if (upcoming)
        {
            var now = DateTime.Now;
            query = query.Where(e => e.EventDate >= now);
        }

        var events = await query.OrderBy(e => e.EventDate).ToListAsync();
        return Ok(events.Select(e => EventDto.From(e)).ToList());
    }

    /// <summary>Get the full details of one event, including its categories.</summary>
    /// <remarks>Role required: none (public).</remarks>
    /// <response code="200">Event details with categories.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEvent(int id)
    {
        var ev = await _db.Events.Include(e => e.Organiser).Include(e => e.Categories)
            .FirstOrDefaultAsync(e => e.EventID == id);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");
        return Ok(EventDto.From(ev, includeCategories: true));
    }

    /// <summary>Create a new event owned by the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser.</remarks>
    /// <response code="201">The new event.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Caller is not an Organiser.</response>
    [HttpPost]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> CreateEvent([FromBody] EventRequest request)
    {
        var type = EventTypes.Normalise(request.EventType);
        if (type is null)
            return Fail(StatusCodes.Status400BadRequest, "Event type must be Run, Walk or Cycle.");

        var ev = new RaceEvent
        {
            OrganiserID = CurrentUserId,
            EventName = request.EventName.Trim(),
            Description = string.IsNullOrWhiteSpace(request.Description) ? null : request.Description.Trim(),
            EventDate = request.EventDate!.Value,
            Location = request.Location.Trim(),
            DistanceKM = request.DistanceKm,
            EventType = type
        };

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();
        await _db.Entry(ev).Reference(e => e.Organiser).LoadAsync();

        return CreatedAtAction(nameof(GetEvent), new { id = ev.EventID }, EventDto.From(ev));
    }

    /// <summary>Update an event that belongs to the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser (owner of the event).</remarks>
    /// <response code="200">The updated event.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpPut("{id:int}")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventRequest request)
    {
        var ev = await _db.Events.Include(e => e.Organiser).FirstOrDefaultAsync(e => e.EventID == id);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");
        if (ev.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only modify events that you created.");

        var type = EventTypes.Normalise(request.EventType);
        if (type is null)
            return Fail(StatusCodes.Status400BadRequest, "Event type must be Run, Walk or Cycle.");

        ev.EventName = request.EventName.Trim();
        ev.Description = string.IsNullOrWhiteSpace(request.Description) ? null : request.Description.Trim();
        ev.EventDate = request.EventDate!.Value;
        ev.Location = request.Location.Trim();
        ev.DistanceKM = request.DistanceKm;
        ev.EventType = type;
        await _db.SaveChangesAsync();

        return Ok(EventDto.From(ev));
    }

    /// <summary>Delete an event owned by the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser (owner of the event). Its categories are deleted with it.</remarks>
    /// <response code="204">Event deleted.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event does not exist.</response>
    /// <response code="409">Event already has enrolments and cannot be deleted.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == id);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");
        if (ev.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only delete events that you created.");

        if (await _db.Enrolments.AnyAsync(e => e.EventID == id))
            return Fail(StatusCodes.Status409Conflict,
                "This event already has enrolments and cannot be deleted.");

        _db.Categories.RemoveRange(_db.Categories.Where(c => c.EventID == id));
        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}

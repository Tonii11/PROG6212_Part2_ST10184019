using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class EnrolmentsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public EnrolmentsController(RaceDayDbContext db) => _db = db;

    private IQueryable<Enrolment> WithDetails() =>
        _db.Enrolments.Include(e => e.Event).Include(e => e.Category).Include(e => e.Participant);

    /// <summary>Enrol the logged-in Participant into an event under a chosen category.</summary>
    /// <remarks>Role required: Participant. The enrolment is recorded immediately with status Confirmed.</remarks>
    /// <response code="201">The enrolment record.</response>
    /// <response code="400">Already enrolled, category belongs to a different event, or the event has already taken place.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Caller is not a Participant.</response>
    /// <response code="404">Event or category does not exist.</response>
    [HttpPost("events/{eventId:int}/enrolments")]
    [SessionAuthorize(Role = RoleNames.Participant)]
    [ProducesResponseType(typeof(EnrolmentDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Enrol(int eventId, [FromBody] EnrolRequest request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");

        var category = await _db.Categories.FirstOrDefaultAsync(c => c.CategoryID == request.CategoryId);
        if (category is null) return Fail(StatusCodes.Status404NotFound, "Category not found.");
        if (category.EventID != eventId)
            return Fail(StatusCodes.Status400BadRequest, "That category does not belong to this event.");

        if (ev.EventDate <= DateTime.Now)
            return Fail(StatusCodes.Status400BadRequest, "This event has already taken place.");

        var participantId = CurrentUserId;
        if (await _db.Enrolments.AnyAsync(e => e.ParticipantID == participantId && e.EventID == eventId))
            return Fail(StatusCodes.Status400BadRequest, "You are already enrolled for this event.");

        var enrolment = new Enrolment
        {
            ParticipantID = participantId,
            EventID = eventId,
            CategoryID = category.CategoryID,
            EnrolmentStatus = EnrolmentStatuses.Confirmed,
            EnrolmentDate = DateTime.Now
        };
        _db.Enrolments.Add(enrolment);
        await _db.SaveChangesAsync();

        var saved = await WithDetails().FirstAsync(e => e.EnrolmentID == enrolment.EnrolmentID);
        return Created("/api/users/me/enrolments", EnrolmentDto.From(saved));
    }

    /// <summary>List every event the logged-in Participant has enrolled for, with status.</summary>
    /// <remarks>Role required: Participant.</remarks>
    /// <response code="200">Array of enrolments.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Caller is not a Participant.</response>
    [HttpGet("users/me/enrolments")]
    [SessionAuthorize(Role = RoleNames.Participant)]
    [ProducesResponseType(typeof(List<EnrolmentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyEnrolments()
    {
        var participantId = CurrentUserId;
        var enrolments = await WithDetails()
            .Where(e => e.ParticipantID == participantId)
            .OrderBy(e => e.Event.EventDate)
            .ToListAsync();
        return Ok(enrolments.Select(EnrolmentDto.From).ToList());
    }

    /// <summary>List all Participants enrolled for an event owned by the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser (owner of the event).</remarks>
    /// <response code="200">Array of enrolments.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("events/{eventId:int}/enrolments")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(typeof(List<EnrolmentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventEnrolments(int eventId)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");
        if (ev.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only view enrolments for events that you created.");

        var enrolments = await WithDetails()
            .Where(e => e.EventID == eventId)
            .OrderBy(e => e.EnrolmentDate)
            .ToListAsync();
        return Ok(enrolments.Select(EnrolmentDto.From).ToList());
    }
}

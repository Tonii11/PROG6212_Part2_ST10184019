using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class ResultsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;

    public ResultsController(RaceDayDbContext db) => _db = db;

    private IQueryable<RaceResult> WithDetails() =>
        _db.Results
            .Include(r => r.Enrolment).ThenInclude(e => e.Event)
            .Include(r => r.Enrolment).ThenInclude(e => e.Category)
            .Include(r => r.Enrolment).ThenInclude(e => e.Participant);

    /// <summary>Capture the finish time and position for a Participant's enrolment.</summary>
    /// <remarks>Role required: Organiser (owner of the event). Only possible once the event has taken place.</remarks>
    /// <response code="201">The result record.</response>
    /// <response code="400">Invalid data, position greater than total finishers, event not yet held, or enrolment cancelled.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Enrolment does not exist.</response>
    /// <response code="409">A result has already been captured for this enrolment.</response>
    [HttpPost("enrolments/{enrolmentId:int}/results")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(typeof(ResultDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CaptureResult(int enrolmentId, [FromBody] ResultRequest request)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Event)
            .FirstOrDefaultAsync(e => e.EnrolmentID == enrolmentId);
        if (enrolment is null) return Fail(StatusCodes.Status404NotFound, "Enrolment not found.");
        if (enrolment.Event.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only capture results for events that you created.");

        if (await _db.Results.AnyAsync(r => r.EnrolmentID == enrolmentId))
            return Fail(StatusCodes.Status409Conflict, "A result has already been captured for this enrolment.");

        if (request.FinishPosition > request.TotalFinishers)
            return Fail(StatusCodes.Status400BadRequest, "Finish position cannot be greater than the total number of finishers.");
        if (enrolment.Event.EventDate > DateTime.Now)
            return Fail(StatusCodes.Status400BadRequest, "Results can only be captured after the event has taken place.");
        if (enrolment.EnrolmentStatus == EnrolmentStatuses.Cancelled)
            return Fail(StatusCodes.Status400BadRequest, "A result cannot be captured for a cancelled enrolment.");

        var result = new RaceResult
        {
            EnrolmentID = enrolmentId,
            FinishTimeSeconds = request.FinishTimeSeconds,
            FinishPosition = request.FinishPosition,
            TotalFinishers = request.TotalFinishers,
            CapturedByUserID = CurrentUserId,
            DateCaptured = DateTime.Now
        };
        _db.Results.Add(result);
        await _db.SaveChangesAsync();

        var saved = await WithDetails().FirstAsync(r => r.ResultID == result.ResultID);
        return Created($"/api/events/{saved.Enrolment.EventID}/results", ResultDto.From(saved));
    }

    /// <summary>Get the logged-in Participant's personal race history and results.</summary>
    /// <remarks>Role required: Participant.</remarks>
    /// <response code="200">Array of results with event name, date, category, finish time and position.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Caller is not a Participant.</response>
    [HttpGet("users/me/results")]
    [SessionAuthorize(Role = RoleNames.Participant)]
    [ProducesResponseType(typeof(List<ResultDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyResults()
    {
        var participantId = CurrentUserId;
        var results = await WithDetails()
            .Where(r => r.Enrolment.ParticipantID == participantId)
            .OrderByDescending(r => r.Enrolment.Event.EventDate)
            .ToListAsync();
        return Ok(results.Select(ResultDto.From).ToList());
    }

    /// <summary>Get all captured results for an event owned by the logged-in Organiser.</summary>
    /// <remarks>Role required: Organiser (owner of the event).</remarks>
    /// <response code="200">Array of results ordered by finish position.</response>
    /// <response code="401">No active session.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event does not exist.</response>
    [HttpGet("events/{eventId:int}/results")]
    [SessionAuthorize(Role = RoleNames.Organiser)]
    [ProducesResponseType(typeof(List<ResultDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventResults(int eventId)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev is null) return Fail(StatusCodes.Status404NotFound, "Event not found.");
        if (ev.OrganiserID != CurrentUserId)
            return Fail(StatusCodes.Status403Forbidden, "You can only view results for events that you created.");

        var results = await WithDetails()
            .Where(r => r.Enrolment.EventID == eventId)
            .OrderBy(r => r.FinishPosition)
            .ToListAsync();
        return Ok(results.Select(ResultDto.From).ToList());
    }
}

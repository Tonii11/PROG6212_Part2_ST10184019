using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IPasswordHasher<User> _hasher;

    public AuthController(RaceDayDbContext db, IPasswordHasher<User> hasher)
    {
        _db = db;
        _hasher = hasher;
    }

    /// <summary>Register a new account as an Organiser or a Participant.</summary>
    /// <remarks>Role required: none (public). The password is hashed before it is stored.</remarks>
    /// <response code="201">Account created; returns the public profile.</response>
    /// <response code="400">Validation failed (missing fields, bad email, short password, unknown role).</response>
    /// <response code="409">Email address is already registered.</response>
    [HttpPost("register")]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        var roleName = RoleNames.Normalise(request.Role);
        if (roleName is null)
            return Fail(StatusCodes.Status400BadRequest, "Role must be either 'Organiser' or 'Participant'.");

        var email = request.Email.Trim().ToLowerInvariant();
        if (await _db.Users.AnyAsync(u => u.Email == email))
            return Fail(StatusCodes.Status409Conflict, "An account with this email address already exists.");

        var role = await _db.Roles.FirstAsync(r => r.RoleName == roleName);
        var user = new User
        {
            RoleID = role.RoleID,
            Role = role,
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            Email = email,
            PhoneNumber = string.IsNullOrWhiteSpace(request.PhoneNumber) ? null : request.PhoneNumber.Trim()
        };
        user.PasswordHash = _hasher.HashPassword(user, request.Password);

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return Created("/api/users/me", UserProfileDto.From(user));
    }

    /// <summary>Log in and start a session that stores the user's ID and role.</summary>
    /// <remarks>Role required: none (public). A session cookie is returned and must be sent on later requests
    /// (Swagger UI does this automatically).</remarks>
    /// <response code="200">Session created; returns the role and a profile summary.</response>
    /// <response code="401">Invalid email or password.</response>
    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Email == email);

        if (user is null || !PasswordMatches(user, request.Password))
            return Fail(StatusCodes.Status401Unauthorized, "Invalid email or password.");

        HttpContext.Session.Clear();
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserID);
        HttpContext.Session.SetString(SessionKeys.Role, user.Role.RoleName);

        return Ok(new LoginResponse { Role = user.Role.RoleName, User = UserProfileDto.From(user) });
    }

    /// <summary>End the current user's session.</summary>
    /// <remarks>Role required: any logged-in user.</remarks>
    /// <response code="200">Session cleared.</response>
    /// <response code="401">No active session.</response>
    [HttpPost("logout")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return Ok(new MessageResponse("You have been logged out."));
    }

    private bool PasswordMatches(User user, string password)
    {
        try
        {
            return _hasher.VerifyHashedPassword(user, user.PasswordHash, password) != PasswordVerificationResult.Failed;
        }
        catch (FormatException)
        {
            // Stored value is not a valid ASP.NET Core Identity hash (e.g. placeholder seed data).
            return false;
        }
    }
}

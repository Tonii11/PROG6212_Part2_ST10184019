using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RaceDay.Api.Dtos;

namespace RaceDay.Api.Filters;

public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string Role = "Role";
}

/// <summary>
/// Session-based authorisation. The login endpoint stores the user's ID and role in the
/// server-side session; this filter reads them on every protected request.
/// No Role set = any logged-in user. Role set = only that role (otherwise 403).
/// Not logged in = 401.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    public string? Role { get; set; }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var session = context.HttpContext.Session;
        var userId = session.GetInt32(SessionKeys.UserId);
        var role = session.GetString(SessionKeys.Role);

        if (userId is null || string.IsNullOrEmpty(role))
        {
            context.Result = new ObjectResult(new MessageResponse("Authentication required. Please log in."))
            {
                StatusCode = StatusCodes.Status401Unauthorized
            };
            return;
        }

        if (Role is not null && !string.Equals(role, Role, StringComparison.OrdinalIgnoreCase))
        {
            context.Result = new ObjectResult(new MessageResponse($"This action is restricted to the {Role} role."))
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }
    }
}

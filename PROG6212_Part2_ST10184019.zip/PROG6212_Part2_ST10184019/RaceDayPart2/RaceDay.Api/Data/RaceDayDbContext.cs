using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

/// <summary>
/// EF Core context. Table names, column names, keys, constraints and defaults
/// are configured to match the Part 1 ERD and SQL script exactly.
/// </summary>
public class RaceDayDbContext : DbContext
{
    public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options) { }

    public DbSet<Role> Roles => Set<Role>();
    public DbSet<User> Users => Set<User>();
    public DbSet<RaceEvent> Events => Set<RaceEvent>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<RaceResult> Results => Set<RaceResult>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<Role>(e =>
        {
            e.ToTable("Roles");
            e.HasKey(x => x.RoleID).HasName("PK_Roles");
            e.Property(x => x.RoleName).HasMaxLength(20).IsUnicode(false).IsRequired();
            e.HasIndex(x => x.RoleName).IsUnique().HasDatabaseName("UQ_Roles_RoleName");
            e.HasData(
                new Role { RoleID = 1, RoleName = RoleNames.Organiser },
                new Role { RoleID = 2, RoleName = RoleNames.Participant });
        });

        mb.Entity<User>(e =>
        {
            e.ToTable("Users");
            e.HasKey(x => x.UserID).HasName("PK_Users");
            e.Property(x => x.FirstName).HasMaxLength(50).IsUnicode(false).IsRequired();
            e.Property(x => x.LastName).HasMaxLength(50).IsUnicode(false).IsRequired();
            e.Property(x => x.Email).HasMaxLength(100).IsUnicode(false).IsRequired();
            e.Property(x => x.PasswordHash).HasMaxLength(255).IsUnicode(false).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.ProfileImageUrl).HasMaxLength(255).IsUnicode(false);
            e.Property(x => x.DateRegistered).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.HasIndex(x => x.Email).IsUnique().HasDatabaseName("UQ_Users_Email");
            e.HasOne(x => x.Role).WithMany(r => r.Users).HasForeignKey(x => x.RoleID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Users_Roles");
        });

        mb.Entity<RaceEvent>(e =>
        {
            e.ToTable("Events", t =>
            {
                t.HasCheckConstraint("CK_Events_EventType", "[EventType] IN ('Run', 'Walk', 'Cycle')");
                t.HasCheckConstraint("CK_Events_DistanceKM", "[DistanceKM] > 0");
            });
            e.HasKey(x => x.EventID).HasName("PK_Events");
            e.Property(x => x.EventName).HasMaxLength(100).IsUnicode(false).IsRequired();
            e.Property(x => x.Description).HasMaxLength(1000).IsUnicode(false);
            e.Property(x => x.EventDate).HasColumnType("datetime");
            e.Property(x => x.Location).HasMaxLength(150).IsUnicode(false).IsRequired();
            e.Property(x => x.DistanceKM).HasColumnType("decimal(6,2)");
            e.Property(x => x.EventType).HasMaxLength(10).IsUnicode(false).IsRequired();
            e.Property(x => x.BannerImageUrl).HasMaxLength(255).IsUnicode(false);
            e.Property(x => x.CreatedAt).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.HasOne(x => x.Organiser).WithMany(u => u.OrganisedEvents).HasForeignKey(x => x.OrganiserID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Events_Organiser");
        });

        mb.Entity<Category>(e =>
        {
            e.ToTable("Categories", t =>
            {
                t.HasCheckConstraint("CK_Categories_AgeRange",
                    "[MinAge] IS NULL OR [MaxAge] IS NULL OR [MinAge] <= [MaxAge]");
            });
            e.HasKey(x => x.CategoryID).HasName("PK_Categories");
            e.Property(x => x.CategoryName).HasMaxLength(50).IsUnicode(false).IsRequired();
            e.Property(x => x.CategoryDistanceKM).HasColumnType("decimal(6,2)");
            e.HasOne(x => x.Event).WithMany(ev => ev.Categories).HasForeignKey(x => x.EventID)
                .OnDelete(DeleteBehavior.Cascade).HasConstraintName("FK_Categories_Events");
        });

        mb.Entity<Enrolment>(e =>
        {
            e.ToTable("Enrolments", t =>
            {
                t.HasCheckConstraint("CK_Enrolments_Status",
                    "[EnrolmentStatus] IN ('Pending', 'Confirmed', 'Cancelled')");
            });
            e.HasKey(x => x.EnrolmentID).HasName("PK_Enrolments");
            e.Property(x => x.EnrolmentDate).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.Property(x => x.EnrolmentStatus).HasMaxLength(20).IsUnicode(false).IsRequired()
                .HasDefaultValue(EnrolmentStatuses.Pending);
            e.HasIndex(x => new { x.ParticipantID, x.EventID }).IsUnique()
                .HasDatabaseName("UQ_Enrolments_ParticipantEvent");
            e.HasOne(x => x.Participant).WithMany(u => u.Enrolments).HasForeignKey(x => x.ParticipantID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Enrolments_Participant");
            e.HasOne(x => x.Event).WithMany(ev => ev.Enrolments).HasForeignKey(x => x.EventID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Enrolments_Event");
            e.HasOne(x => x.Category).WithMany(c => c.Enrolments).HasForeignKey(x => x.CategoryID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Enrolments_Category");
        });

        mb.Entity<RaceResult>(e =>
        {
            e.ToTable("Results", t =>
            {
                t.HasCheckConstraint("CK_Results_Position",
                    "[FinishPosition] > 0 AND [FinishPosition] <= [TotalFinishers]");
            });
            e.HasKey(x => x.ResultID).HasName("PK_Results");
            e.Property(x => x.DateCaptured).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.HasIndex(x => x.EnrolmentID).IsUnique().HasDatabaseName("UQ_Results_Enrolment");
            e.HasOne(x => x.Enrolment).WithOne(en => en.Result).HasForeignKey<RaceResult>(x => x.EnrolmentID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Results_Enrolment");
            e.HasOne(x => x.CapturedBy).WithMany().HasForeignKey(x => x.CapturedByUserID)
                .OnDelete(DeleteBehavior.Restrict).HasConstraintName("FK_Results_CapturedBy");
        });
    }
}

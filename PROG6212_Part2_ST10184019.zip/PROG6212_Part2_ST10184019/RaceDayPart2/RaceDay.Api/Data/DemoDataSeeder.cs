using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

/// <summary>
/// Development-only helper so the API can be demonstrated straight away.
/// - Empty database: inserts the same sample data as the Part 1 SQL script, with real hashed passwords.
/// - Database created by the Part 1 script: its placeholder hashes cannot be verified, so they are
///   replaced with a hash of the demo password. Never runs outside Development.
/// </summary>
public static class DemoDataSeeder
{
    public const string DemoPassword = "Password123!";

    public static async Task SeedAsync(RaceDayDbContext db, IPasswordHasher<User> hasher)
    {
        if (await db.Users.AnyAsync())
        {
            var placeholders = await db.Users.Where(u => u.PasswordHash.EndsWith("$hashed")).ToListAsync();
            foreach (var u in placeholders) u.PasswordHash = hasher.HashPassword(u, DemoPassword);
            if (placeholders.Count > 0) await db.SaveChangesAsync();
            return;
        }

        User NewUser(int roleId, string first, string last, string email, string phone)
        {
            var u = new User { RoleID = roleId, FirstName = first, LastName = last, Email = email, PhoneNumber = phone };
            u.PasswordHash = hasher.HashPassword(u, DemoPassword);
            return u;
        }

        var naledi = NewUser(1, "Naledi", "Khumalo", "naledi.khumalo@raceday.co.za", "0821234567");
        var pieter = NewUser(1, "Pieter", "van der Merwe", "pieter.vdm@raceday.co.za", "0837654321");
        var thandeka = NewUser(2, "Thandeka", "Mokoena", "thandeka.mokoena@gmail.com", "0712223333");
        var ryan = NewUser(2, "Ryan", "Botha", "ryan.botha@gmail.com", "0794445555");
        db.Users.AddRange(naledi, pieter, thandeka, ryan);

        var sunrise = new RaceEvent
        {
            Organiser = naledi, EventName = "Joburg Sunrise 10K", EventType = "Run", DistanceKM = 10m,
            Location = "Sandton, Johannesburg", EventDate = new DateTime(2026, 8, 2, 6, 0, 0),
            Description = "A fast, flat 10km road run through Sandton starting at sunrise."
        };
        var vaal = new RaceEvent
        {
            Organiser = naledi, EventName = "Vaal Dam Cycle Classic", EventType = "Cycle", DistanceKM = 60m,
            Location = "Vaal Dam, Gauteng", EventDate = new DateTime(2026, 11, 8, 7, 0, 0),
            Description = "A scenic road cycling race around the Vaal Dam for all skill levels."
        };
        var walk = new RaceEvent
        {
            Organiser = pieter, EventName = "Cape Winelands Charity Walk", EventType = "Walk", DistanceKM = 5m,
            Location = "Stellenbosch, Western Cape", EventDate = new DateTime(2026, 10, 18, 8, 0, 0),
            Description = "A family-friendly charity walk through the Cape Winelands raising funds for local schools."
        };
        db.Events.AddRange(sunrise, vaal, walk);

        var open10 = new Category { Event = sunrise, CategoryName = "Open 10km", MinAge = 16, MaxAge = 99, CategoryDistanceKM = 10m };
        var junior10 = new Category { Event = sunrise, CategoryName = "Junior 10km", MinAge = 12, MaxAge = 15, CategoryDistanceKM = 10m };
        var ind60 = new Category { Event = vaal, CategoryName = "60km Individual", MinAge = 18, MaxAge = 99, CategoryDistanceKM = 60m };
        var relay60 = new Category { Event = vaal, CategoryName = "60km Team Relay", MinAge = 18, MaxAge = 99, CategoryDistanceKM = 60m };
        var family5 = new Category { Event = walk, CategoryName = "5km Family Walk", MinAge = 0, MaxAge = 99, CategoryDistanceKM = 5m };
        db.Categories.AddRange(open10, junior10, ind60, relay60, family5);

        var e1 = new Enrolment { Participant = thandeka, Event = sunrise, Category = open10, EnrolmentStatus = EnrolmentStatuses.Confirmed };
        var e2 = new Enrolment { Participant = ryan, Event = vaal, Category = ind60, EnrolmentStatus = EnrolmentStatuses.Confirmed };
        var e3 = new Enrolment { Participant = thandeka, Event = walk, Category = family5, EnrolmentStatus = EnrolmentStatuses.Confirmed };
        db.Enrolments.AddRange(e1, e2, e3);

        db.Results.Add(new RaceResult
        {
            Enrolment = e1, FinishTimeSeconds = 2415, FinishPosition = 47, TotalFinishers = 312, CapturedBy = naledi
        });

        await db.SaveChangesAsync();
    }
}

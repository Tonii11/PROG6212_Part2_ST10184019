namespace RaceDay.Api.Models;

/// <summary>Lookup table: Organiser / Participant.</summary>
public class Role
{
    public int RoleID { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public ICollection<User> Users { get; set; } = new List<User>();
}

public class User
{
    public int UserID { get; set; }
    public int RoleID { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string? ProfileImageUrl { get; set; }
    public DateTime DateRegistered { get; set; } = DateTime.Now;

    public Role Role { get; set; } = null!;
    public ICollection<RaceEvent> OrganisedEvents { get; set; } = new List<RaceEvent>();
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

/// <summary>Mapped to the "Events" table.</summary>
public class RaceEvent
{
    public int EventID { get; set; }
    public int OrganiserID { get; set; }
    public string EventName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal DistanceKM { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string? BannerImageUrl { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public User Organiser { get; set; } = null!;
    public ICollection<Category> Categories { get; set; } = new List<Category>();
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

public class Category
{
    public int CategoryID { get; set; }
    public int EventID { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int? MinAge { get; set; }
    public int? MaxAge { get; set; }
    public decimal? CategoryDistanceKM { get; set; }

    public RaceEvent Event { get; set; } = null!;
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}

public class Enrolment
{
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public int EventID { get; set; }
    public int CategoryID { get; set; }
    public DateTime EnrolmentDate { get; set; } = DateTime.Now;
    public string EnrolmentStatus { get; set; } = EnrolmentStatuses.Pending;

    public User Participant { get; set; } = null!;
    public RaceEvent Event { get; set; } = null!;
    public Category Category { get; set; } = null!;
    public RaceResult? Result { get; set; }
}

/// <summary>Mapped to the "Results" table.</summary>
public class RaceResult
{
    public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public int FinishTimeSeconds { get; set; }
    public int FinishPosition { get; set; }
    public int TotalFinishers { get; set; }
    public int CapturedByUserID { get; set; }
    public DateTime DateCaptured { get; set; } = DateTime.Now;

    public Enrolment Enrolment { get; set; } = null!;
    public User CapturedBy { get; set; } = null!;
}

public static class RoleNames
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";

    public static string? Normalise(string? value)
    {
        var v = value?.Trim();
        if (string.Equals(v, Organiser, StringComparison.OrdinalIgnoreCase)) return Organiser;
        if (string.Equals(v, Participant, StringComparison.OrdinalIgnoreCase)) return Participant;
        return null;
    }
}

public static class EventTypes
{
    public static readonly string[] All = { "Run", "Walk", "Cycle" };

    public static string? Normalise(string? value) =>
        All.FirstOrDefault(t => string.Equals(t, value?.Trim(), StringComparison.OrdinalIgnoreCase));
}

public static class EnrolmentStatuses
{
    public const string Pending = "Pending";
    public const string Confirmed = "Confirmed";
    public const string Cancelled = "Cancelled";
}
